import { Component, OnInit } from '@angular/core';
import { DataAdminService } from '../data-admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-feedback',
  templateUrl: './delete-feedback.component.html',
  styleUrls: ['./delete-feedback.component.css']
})
export class DeleteFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
   

}
